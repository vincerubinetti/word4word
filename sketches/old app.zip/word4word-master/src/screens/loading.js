import React from 'react';

import { ReactComponent as Loading } from '../loading.svg';

export default () => <Loading width='40px' />;
